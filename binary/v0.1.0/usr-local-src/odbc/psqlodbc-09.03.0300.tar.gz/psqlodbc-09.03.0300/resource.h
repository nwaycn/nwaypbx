//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by psqlodbc.rc
//
#define IDS_BADDSN                      1
#define IDS_MSGTITLE                    2
#define IDS_ADVANCE_OPTION_DEF          3
#define IDOK2                           3
#define IDS_ADVANCE_SAVE                4
#define IDCANCEL2                       4
#define IDS_ADVANCE_OPTION_DSN1         5
#define IDS_ADVANCE_OPTION_CON1         6
#define IDS_ADVANCE_OPTION_DSN2         7
#define IDS_ADVANCE_OPTION_CON2         8
#define IDS_ADVANCE_CONNECTION          9
#define DLG_OPTIONS_DRV                 102
#define DLG_OPTIONS_DS                  103
#define DLG_OPTIONS_GLOBAL		104
#define IDC_DSNAME			400
#define IDC_DSNAMETEXT			401
#define IDC_DESC			404
#define IDC_SERVER			407
#define IDC_DATABASE			408
#define IDC_SSLMODE			409
#define IDS_SSLREQUEST_PREFER		410
#define IDS_SSLREQUEST_ALLOW		411
#define IDS_SSLREQUEST_REQUIRE		412
#define IDS_SSLREQUEST_DISABLE		413
#define IDC_NOTICE_USER			414
#define IDS_SSLREQUEST_VERIFY_CA	415
#define IDS_SSLREQUEST_VERIFY_FULL	416
#define DLG_CONFIG                      1001
#define IDC_PORT                        1002
#define DLG_DRIVER_CHANGE               1002
#define IDC_USER                        1006
#define IDC_PASSWORD                    1009
#define DS_READONLY                     1011
#define DS_SHOWOIDCOLUMN                1012
#define DS_FAKEOIDINDEX                 1013
#define DRV_COMMLOG                     1014
#define DS_PG62                         1016
#define IDC_DATASOURCE                  1018
#define DRV_OPTIMIZER                   1019
#define DS_CONNSETTINGS                 1020
#define IDC_DRIVER                      1021
#define DRV_CONNSETTINGS                1031
#define DRV_UNIQUEINDEX                 1032
#define DRV_UNKNOWN_MAX                 1035
#define DRV_UNKNOWN_DONTKNOW            1036
#define DRV_READONLY                    1037
#define IDC_DESCTEXT                    1039
#define DRV_MSG_LABEL                   1040
#define DRV_UNKNOWN_LONGEST             1041
#define DRV_TEXT_LONGVARCHAR            1043
#define DRV_UNKNOWNS_LONGVARCHAR        1044
#define DRV_CACHE_SIZE                  1045
#define DRV_VARCHAR_SIZE                1046
#define DRV_LONGVARCHAR_SIZE            1047
#define IDDEFAULTS                      1048
#define DRV_USEDECLAREFETCH             1049
#define DRV_BOOLS_CHAR                  1050
#define DS_SHOWSYSTEMTABLES             1051
#define DRV_EXTRASYSTABLEPREFIXES       1051
#define DS_ROWVERSIONING                1052
#define DRV_PARSE                       1052
#define DRV_CANCELASFREESTMT            1053
#define IDC_OPTIONS                     1054
#define DRV_KSQO                        1055
#define DS_PG64                         1057
#define DS_PG63                         1058
#define DRV_OR_DSN                      1059
#define DRV_DEBUG                       1060
#define DS_DISALLOWPREMATURE            1061
#define DS_LFCONVERSION                 1062
#define DS_TRUEISMINUS1                 1063
#define DS_UPDATABLECURSORS             1064
#define IDNEXTPAGE                      1065
#define IDPREVPAGE                      1066
#define DS_INT8_AS_DEFAULT              1067
#define DS_INT8_AS_BIGINT               1068
#define DS_INT8_AS_NUMERIC              1069
#define DS_INT8_AS_VARCHAR              1070
#define DS_INT8_AS_DOUBLE               1071
#define DS_INT8_AS_INT4                 1072
#define DRV_MSG_LABEL2                  1073
#define DS_BYTEAASLONGVARBINARY         1073
#define IDAPPLY                         1074
#define DS_SERVERSIDEPREPARE            1075
#define IDC_DRIVERNAME                  1076
#define IDC_MANAGEDSN                   1077
#define IDC_DRIVER_LIST                 1078
#define DS_PG74				1079
#define DS_NO_ROLLBACK			1080
#define DS_TRANSACTION_ROLLBACK		1081
#define DS_STATEMENT_ROLLBACK		1082
#define DRV_DTCLOG			1083
#define DS_EXTRA_OPTIONS		1084
#define IDC_TEST			1085
#define DS_LOGDIR			1086
#define DS_GSSAUTHUSEGSSAPI		1087

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1088
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
